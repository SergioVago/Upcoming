package com.example.upcoming_series;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tela_opcao_serie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_opcao_serie);
    }


}
